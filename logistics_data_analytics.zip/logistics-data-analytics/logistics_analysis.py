"""Starter analysis for a last-mile delivery dataset.

Expected CSV: deliveries.csv
Expected columns: order_id, dispatch_time, promised_delivery_time,
actual_delivery_time, distance_km

Adapt column names and assumptions to the dataset you choose.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA_PATH = Path("deliveries.csv")
TIME_COLUMNS = [
    "dispatch_time",
    "promised_delivery_time",
    "actual_delivery_time",
]


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            "Missing deliveries.csv. Add a permitted public or synthetic "
            "dataset and update README.md with its source and licence."
        )

    df = pd.read_csv(DATA_PATH)

    required = {
        "order_id",
        "dispatch_time",
        "promised_delivery_time",
        "actual_delivery_time",
        "distance_km",
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    print("Dataset shape:", df.shape)
    print("\nMissing values (top 10):")
    print(df.isna().sum().sort_values(ascending=False).head(10))
    print("\nDuplicate order IDs:", df.duplicated(subset=["order_id"]).sum())

    for col in TIME_COLUMNS:
        df[col] = pd.to_datetime(df[col], errors="coerce")

    # Keep one record per order for this simple example.
    df = df.drop_duplicates(subset=["order_id"]).copy()
    completed = df.dropna(
        subset=["dispatch_time", "promised_delivery_time", "actual_delivery_time"]
    ).copy()

    completed["delivery_minutes"] = (
        completed["actual_delivery_time"] - completed["dispatch_time"]
    ).dt.total_seconds() / 60
    completed["delay_minutes"] = (
        completed["actual_delivery_time"] - completed["promised_delivery_time"]
    ).dt.total_seconds() / 60
    completed["on_time"] = completed["delay_minutes"] <= 0

    # Flag invalid values for review rather than silently accepting them.
    invalid_duration = completed["delivery_minutes"] < 0
    if invalid_duration.any():
        print(f"Warning: {invalid_duration.sum()} records have negative delivery duration.")
        completed = completed.loc[~invalid_duration].copy()

    if completed.empty:
        raise ValueError("No valid completed deliveries remain after cleaning.")

    on_time_rate = completed["on_time"].mean() * 100
    avg_duration = completed["delivery_minutes"].mean()
    avg_distance = pd.to_numeric(completed["distance_km"], errors="coerce").mean()
    avg_delay = completed["delay_minutes"].mean()

    print("\n--- Baseline KPIs ---")
    print(f"Completed deliveries: {len(completed)}")
    print(f"On-time delivery rate: {on_time_rate:.1f}%")
    print(f"Average delivery duration: {avg_duration:.1f} minutes")
    print(f"Average distance per delivery: {avg_distance:.2f} km")
    print(f"Average delay (late and early deliveries included): {avg_delay:.1f} minutes")

    # Exploratory chart: average delay by dispatch weekday.
    completed["dispatch_weekday"] = completed["dispatch_time"].dt.day_name()
    weekday_order = [
        "Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday",
    ]
    daily_delay = (
        completed.groupby("dispatch_weekday")["delay_minutes"]
        .mean()
        .reindex(weekday_order)
        .dropna()
    )

    if not daily_delay.empty:
        daily_delay.plot(kind="bar", title="Average delivery delay by dispatch weekday")
        plt.ylabel("Delay (minutes; negative means early)")
        plt.xlabel("Dispatch weekday")
        plt.tight_layout()
        plt.savefig("average_delay_by_weekday.png", dpi=150)
        print("\nSaved chart: average_delay_by_weekday.png")
        # Close the plot to avoid blocking automated runs.
        plt.close()


if __name__ == "__main__":
    main()
