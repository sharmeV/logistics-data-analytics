# Logistics Data Analytics — Week 1 Project

## Project overview
This project proposes a Python-based analysis of last-mile delivery performance for a fictional e-commerce logistics company. It demonstrates data inspection, KPI calculation, exploratory analysis, and a starter approach for identifying late deliveries.

**Important:** This is a starter project using a CSV file you provide. No operational results are claimed. Use a permitted public or synthetic dataset and document its source and licence.

## Business questions
- What percentage of completed deliveries arrived on or before the promised time?
- What is the average delivery duration and distance per delivery?
- How do delays vary by dispatch weekday?
- Which factors may help predict late deliveries?

## KPIs
1. On-time delivery rate = on-time completed deliveries / completed deliveries × 100
2. Average delivery duration in minutes
3. Average distance per completed delivery (km)
4. Average delay in minutes

## Expected input
Place a CSV file named `deliveries.csv` in the project folder. Adapt the column names in `logistics_analysis.py` to match your dataset. The starter script expects:
- `order_id`
- `dispatch_time`
- `promised_delivery_time`
- `actual_delivery_time`
- `distance_km`

Times should be parseable timestamps. Missing actual delivery times are treated as incomplete deliveries and excluded from completed-delivery KPIs.

## Setup
```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install packages:
```bash
pip install -r requirements.txt
```

Run:
```bash
python logistics_analysis.py
```

## Project roadmap
1. Collect a permitted public or synthetic dataset.
2. Audit missing values, duplicates, timestamp formats, and invalid values.
3. Calculate baseline KPIs and explore delay patterns.
4. Add features available before dispatch and evaluate a delay-risk model with a chronological split.
5. Explore service-zone clustering if location/zone data is available.
6. Prototype vehicle routing with capacity and time-window constraints if stop coordinates and travel-time data are available.
7. Compare proposed changes against a baseline before making operational recommendations.

## Limitations
The code is illustrative and requires a compatible dataset. Public datasets may not represent a specific company's costs, traffic, or delivery promises. Predictive associations do not establish causation. Avoid uploading personal or confidential delivery/customer data to a public repository.

## Data source
Add the exact dataset title, publisher, URL, access date, and licence here after selecting the dataset.
